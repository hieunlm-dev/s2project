<h2>Hello Admin,</h2> <br> 
You received an email from : {{ $name }} <br>
Here are the details:<br>
<b>Name:</b> {{ $name }}<br>
<b>Email:</b> {{ $email }}<br>
<b>Phone Number:</b> {{ $phone}}<br>
<b>Subject:</b> {{ $subject }}<br>
<b>Message:</b> <br>
 {!! $user_message !!}

<br><br>
Thank You!