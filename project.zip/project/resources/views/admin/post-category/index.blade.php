@extends('admin.layout.layout')

@section('contents')
<!-- Content Header (Page header) -->
<section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1>Post Categories</h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="#">Home</a></li>
            <li class="breadcrumb-item active">Post Categories</li>
          </ol>
        </div>
      </div>
    </div><!-- /.container-fluid -->
  </section>

  <!-- Main content -->
  <section class="content">

    <!-- Default box -->
    <div class="card">
      <div class="card-header">
        <h3 class="card-title">Post Categories Index</h3>

        <div class="card-tools">
          <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
            <i class="fas fa-minus"></i>
          </button>
          <button type="button" class="btn btn-tool" data-card-widget="remove" title="Remove">
            <i class="fas fa-times"></i>
          </button>
        </div>
      </div>
      <div class="card-body p-0">
        <div>
            @if(session('alert'))
          
              <section class='alert alert-warning'>{{session('alert')}}</section>
          
          @endif  
        </div>
        <table class="table table-striped projects">
          <thead>
              <tr>
                <th>Name</th>
                <th>Slug</th>
                <th>Sort</th>

                <th>Actions</th>
              </tr>
          </thead>
          <tbody>
            @foreach($postCategories as $item)
            <tr>
              <td>{{ $item->name }}</td>
              <td>{{ $item->slug }}</td>
              <td>{{ $item->sort }}</td>

              <td>
                <form style="display:inline-block" action="{{ route('admin.post-category.destroy', $item->id) }}" method="POST">
                  @method("DELETE")
                  @csrf
                  <button class="btn btn-danger">Delete</button>
                </form>
              </td>
            </tr>
            @endforeach
          </tbody>
      </table>
      </div>
      <!-- /.card-body -->
    </div>
    <!-- /.card -->

  </section>
  <!-- /.content -->
@endsection