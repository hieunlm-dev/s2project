<div class="slide-carousel owl-carousel style-nav-1" data-items="1" data-loop="1" data-nav="true" data-dots="false">
    <div class="item-slide">
        <img src="<?php echo e(asset('assets/images/preview.jpg')); ?>" alt="" class="img-slide">
        
    </div>
    <div class="item-slide">
        <img src="<?php echo e(asset('assets/images/slider2.jpg')); ?>" alt="" class="img-slide">
        
    </div>
    <div class="item-slide">
        <img src="<?php echo e(asset('assets/images/main-slider-1-3.jpg')); ?>" alt="" class="img-slide">
        
    </div>
</div><?php /**PATH /Users/sorcerersupreme/Documents/Programing/Workspace/GitHub/s2project/project/resources/views/frontend/home/slideshow.blade.php ENDPATH**/ ?>