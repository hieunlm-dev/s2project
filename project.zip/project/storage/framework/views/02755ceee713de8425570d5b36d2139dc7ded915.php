<?php $__env->startSection('contents'); ?>

<div class="container">

			<div class="wrap-breadcrumb">
				<ul>
					<li class="item-link"><a href="#" class="link">Home</a></li>
					<li class="item-link"><span>Shop</span></li>
				</ul>
			</div>
			<div class="row">

				<div class="col-lg-9 col-md-8 col-sm-8 col-xs-12 main-content-area">

					<div class="banner-shop">
						<a href="#" class="banner-link">
							<figure><img src="assets/images/shop-banner.jpg" alt=""></figure>
						</a>
					</div>

					<div class="wrap-shop-control">

						<h1 class="shop-title">Shop</h1>

						

					</div><!--end wrap shop control-->

					<div class="row">
						<ul class="product-list grid-products equal-container">
                            <!-- <?php if($products->isNotEmpty()): ?> -->
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<li class="col-lg-4 col-md-6 col-sm-6 col-xs-6 ">
								<div class="product product-style-3 equal-elem ">
									<div class="product-thumnail">
										<a href="<?php echo e(route('product-details',$item->id)); ?>" title="<?php echo e($item->name); ?>">
											<figure><img src="<?php echo e(asset('images/'.$item->image)); ?>" alt="img"></figure>
										</a>
									</div>
									<div class="product-info">
										<a href="<?php echo e(route('product-details',$item->id)); ?>" class="product-name"><span><?php echo e($item->name); ?></span></a>
										<div class="wrap-price"><span class="product-price"><?php echo e($item->price); ?></span></div>
										
									</div>
								</div>
							</li>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <!-- <?php else: ?> 
                            <div>
                                <h2>No posts found</h2>
                            </div>
                            <?php endif; ?> -->
						</ul>

					</div>
					<div class="wrap-pagination-info">
						<div class="d-flex justify-content-center">
							<?php echo $products->links(); ?>

						</div>
					</div>
				</div><!--end main products area-->

				<div class="col-lg-3 col-md-4 col-sm-4 col-xs-12 sitebar">
				</div><!--end sitebar-->

			</div><!--end row-->

		</div><!--end container-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sorcerersupreme/Documents/Programing/Workspace/GitHub/s2project/project/resources/views/frontend/search.blade.php ENDPATH**/ ?>