<style>
    ul>li:hover>a{
    background-color: #blue;
}
</style>
<div class="container-fluid">
    <div class="row">
        <div class="topbar-menu-area">
            <div class="container">
                <div class="topbar-menu left-menu">
                    <ul>
                        <li class="menu-item" >
                            <a title="Hotline" href="#" ><span class="icon label-before fa fa-mobile"></span>Hotline: (+84) 98 157 89 20</a>
                        </li>
                    </ul>
                </div>
                <div class="topbar-menu right-menu">
                    <ul>
                        <?php if(session()->has('customer')): ?>
                            <li class="menu-item" ><a title="User" href="<?php echo e(route('customer.edit',session()->get('customer')->id)); ?>"> Welcome <i><b><?php echo e(Session::get('customer')->email); ?></b></i></a></li>
                            <li class="menu-item" ><a title="Logout" href="<?php echo e(route('logout')); ?>">Sign out</a></li>
                        <?php else: ?> 
                            <li class="menu-item" ><a title="Register or Login" href="<?php echo e(route('login')); ?>">Login</a></li>
                            <li class="menu-item" ><a title="Register or Login" href="<?php echo e(route('customer.create')); ?>">Register</a></li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </div>

        <div class="container">
            <div class="mid-section main-info-area">

                <div class="wrap-logo-top left-section">
                    <a href="<?php echo e(route('home')); ?>" class="link-to-home"><img src="<?php echo e(asset('images/logo.jpg')); ?>" alt="mercado"></a>
                </div>

                <div class="wrap-search center-section">
                    <div class="wrap-search-form" >
                        <form action="<?php echo e(route('search')); ?>" id="form-search-top" name="form-search-top" method="GET">
                            
                            <input id="search" name="search" type="text" placeholder="Search here..." />
                            <button form="form-search-top" type="submit"><i class="fa fa-search" aria-hidden="true" ></i></button>
                        </form>
                    </div>
                </div>

                <div class="wrap-icon right-section">
                    <div class="wrap-icon-section wishlist">
                        <a href="<?php if(Session::has('customer')): ?><?php echo e(route('wish-list.index')); ?><?php else: ?><?php echo e(route('login')); ?> <?php endif; ?>" class="link-direction">
                            <i class="fa fa-heart" aria-hidden="true"></i>
                            <div class="left-info">
                                <?php if(isset($lists)): ?>
                                <?php
                                    $count =0;
                                ?>
                                <?php $__currentLoopData = $lists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(isset($item)): ?>
                                        <?php
                                            $count++;
                                        ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                                <span class="index">
                                    <?php if(isset($lists)): ?>
                                    <?php echo e($count); ?> items
                                    <?php else: ?> 
                                    0 items
                                    <?php endif; ?>
                                </span>
                                <span class="title">Wishlist</span>
                            </div>
                        </a>
                    </div>
                    <div class="wrap-icon-section minicart">
                        <a href="<?php echo e(route('view-cart')); ?>" class="link-direction">
                            <i class="fa fa-shopping-basket" aria-hidden="true"></i>
                            <div class="left-info">
                                <span class="index"> 
                                <?php
                                    $count = 0;
                                ?>
                                <?php if(Session::has('cart')): ?>
                                    <?php $__currentLoopData = Session::get('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(isset($item)): ?>
                                            <?php
                                                $count++;
                                            ?>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                                <?php if(Session::has('cart')): ?>
                                    <?php echo e($count); ?>

                                <?php else: ?>
                                    0
                                <?php endif; ?>    
                                </span>
                                <span class="title">CART</span>
                            </div>
                        </a>
                    </div>
                    <div class="wrap-icon-section show-up-after-1024">
                        <a href="#" class="mobile-navigation">
                            <span></span>
                            <span></span>
                            <span></span>
                        </a>
                    </div>
                </div>

            </div>
        </div>

        <div class="nav-section header-sticky">
            <div class="primary-nav-section">
                <div class="container">
                    <ul class="nav primary clone-main-menu" id="mercado_main" data-menuname="Main menu" >
                        <li class="menu-item home-icon">
                            <a href="<?php echo e(route('home')); ?>" class="link-term mercado-item-title"><i class="fa fa-home" aria-hidden="true"></i></a>
                        </li>
                        <li class="menu-item" >
                            <a href="<?php echo e(route('about')); ?>" class="link-term mercado-item-title"  >About Us</a>
                        </li>
                        <li class="menu-item">
                            <a href="<?php echo e(route('shop')); ?>" class="link-term mercado-item-title" >Shop</a>
                        </li>
                        <li class="menu-item">
                            <a href="<?php echo e(route('view-cart')); ?>" class="link-term mercado-item-title" >Cart</a>
                        </li>
                        <li class="menu-item">
                            <a href="<?php echo e(route('checkout')); ?>" class="link-term mercado-item-title" >Checkout</a>
                        </li>
                        <li class="menu-item">
                            <a href="<?php echo e(route('history.index')); ?>" class="link-term mercado-item-title" >Order History</a>
                        </li>	
                        <li class="menu-item">
                            <a href="<?php echo e(route('post-index')); ?>" class="link-term mercado-item-title" >Blog</a>
                        </li>		
                        <li class="menu-item">
                            <a href="<?php echo e(route('contact')); ?>" class="link-term mercado-item-title" >Contact Us</a>
                        </li>														
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>

<?php /**PATH /Users/sorcerersupreme/Documents/Programing/Workspace/GitHub/s2project/project/resources/views/frontend/layout/partials/header.blade.php ENDPATH**/ ?>