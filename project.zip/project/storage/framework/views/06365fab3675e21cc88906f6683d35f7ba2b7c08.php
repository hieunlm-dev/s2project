<?php $__env->startSection('contents'); ?>

<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<div class="container">

			<div class="wrap-breadcrumb">
				<ul>
					<li class="item-link"><a href="<?php echo e(route('home')); ?>" class="link">home</a></li>
					<li class="item-link"><span>View Cart</span></li>
				</ul>
			</div>
			<div class=" main-content-area">

				<form action="">
				<?php
					$total=0;
				?>
				<div class="wrap-iten-in-cart">
					<h3 class="box-title">Products Name</h3>
					<?php if(Session::has('cart')): ?>
					<ul class="products-cart">
						

						<?php $__currentLoopData = Session::get('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

						<?php
							$total+= $item->quantity * $item->price;
						?>
						<li class="pr-cart-item">
							<div class="product-image">
								<figure><img src="<?php echo e(asset('images/' . $item -> image)); ?>" alt="<?php echo e($item->name); ?>"></figure>
							</div>
							<div class="product-name">
								<a class="link-to-product" href="<?php echo e(route('product-details',$item->id)); ?>"><?php echo e($item->name); ?></a>
							</div>
							<div class="price-field produtc-price"><p class="price"><?php echo e(number_format($item->price,0,'','.')); ?> ₫</p></div>
							<div class="quantity" >
								<div class="quantity-input" >
									<input type="text" name="product-quantity" data-id=<?php echo e($item->id); ?> value="<?php echo e($item->quantity); ?>" data-max="120" pattern="[0-9]*" >									
									<a class="btn btn-increase" href="#"></a>
									<a class="btn btn-reduce" href="#"></a>
								</div>
							</div>
							<div class="price-field sub-total"><p class="price"><?php echo e(number_format($item->quantity*$item->price,0,'','.')); ?> ₫</p></div>
							<div class="delete" >
								<a href="#" class="btn btn-delete" title="" data-id=<?php echo e($item->id); ?> " >
									<span>Delete from your cart</span>
									<i class="fa fa-times-circle" aria-hidden="true"></i>
								</a>
							</div>
						</li>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>					
					</ul>
					<?php endif; ?>
				</div>

				<div class="summary" style="background-color: #fdfdfd; width: 100%; border: 1px solid #e6e6e6;
				padding: 25px 40px 21px 40px; display: table; margin-top: 20px;">
					<div class="order-summary" style="width:371px; padding-right: 75px;
					display: table-cell; vertical-align: middle;">
						<h4 class="title-box">Order Summary</h4>
						<p class="summary-info"><span class="title">Subtotal</span><b class="index"><?php echo e(number_format($total,0,'','.')); ?> ₫</b></p>
						<p class="summary-info"><span class="title">Shipping</span><b class="index">Free Shipping</b></p>
						<p class="summary-info total-info "><span class="title">Total</span><b class="index"><?php echo e(number_format($total,0,'','.')); ?> ₫</b></p>
					</div>
					<div class="checkout-info" style="width: 259px; padding-right: 10px;
					display: table-cell; vertical-align: middle;">
						
						<a class="btn btn-checkout" href="<?php echo e(route('checkout')); ?>">Check out</a>
						<a class="link-to-shop" href="<?php echo e(route('home')); ?>">Continue Shopping<i class="fa fa-arrow-circle-right" aria-hidden="true"></i></a>
					</div>
					<div class="update-clear" style="display: table-cell; vertical-align: middle;">
						<a class="btn btn-clear" href="<?php echo e(route('clear-cart')); ?>">Clear Shopping Cart</a>
					</div>
				</div>

				</form>

			</div><!--end main content area-->
		</div><!--end container-->


<?php $__env->stopSection(); ?>


<?php $__env->startSection('my-scripts'); ?>

<script>
	// setup csrf-token cho post method
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

    // $('.btn-delete').click(function(e) {
		
	$("body").on("click",".btn-delete",function(e){
        e.preventDefault();     // hủy chức năng chuyển trang của thẻ a
        pid=$(this).data("id");
		var current_object = $(this);

        $.ajax({
            type:'GET',
            url:'<?php echo e(route('delete-cart-item')); ?>',
            data:{pid:pid},
            success:function(data){
				swal({
					title: "Delete completed",
					text: "This product has been removed from your cart",
					icon: "success",
					type: "success",
					button: "Okay!",
				}).then(function(){ 
       				location.reload();
   				}
			);
				// window.location='<?php echo e(route('view-cart')); ?>';
            }
        });	
	})


	$(".quantity-input").on('click', '.btn', function(event) {
		event.preventDefault();
		
		var _this = $(this),
			_input = _this.siblings('input[name=product-quantity]'),
			_current_value = _this.siblings('input[name=product-quantity]').val(),
			_max_value = _this.siblings('input[name=product-quantity]').attr('data-max');
		if(_this.hasClass('btn-reduce')){
			if (parseInt(_current_value, 10) > 1) _input.val(parseInt(_current_value, 10) - 1);
		}else {
			if (parseInt(_current_value, 10) < parseInt(_max_value, 10)) _input.val(parseInt(_current_value, 10) + 1);
		}

		// pid=$('.quantity-input').data("id");
		pid = _input.data("id");
		quantity = _input.val();
		$.ajax({
            type:'GET',
            url:'<?php echo e(route('change-cart-quantity')); ?>',
            data:{pid:pid,quantity:quantity},
            success:function(data){
				window.location='<?php echo e(route('view-cart')); ?>';
            }
        });	
	});
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sorcerersupreme/Documents/Programing/Workspace/GitHub/s2project/project/resources/views/frontend/viewcart.blade.php ENDPATH**/ ?>