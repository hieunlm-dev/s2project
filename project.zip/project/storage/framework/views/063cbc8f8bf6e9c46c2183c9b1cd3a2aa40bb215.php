<?php $__env->startSection('contents'); ?>


<div class="container">

<center><h2>Order History</h2></center>
<div>
    <?php if(session('alert')): ?>
  
      <section class='alert alert-success'><?php echo e(session('alert')); ?></section>
  
  <?php endif; ?>  
</div>
<div class="card-body p-0">
    <table class="table table-striped projects">
      <thead>
          <tr>
            <th>Order ID</th>
            <th>Order Date</th>
            <th>Customer Address</th>
            <th>Total Money</th>
            <th>Status</th>
            <th>Action</th>
          </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($item->id); ?></td>
          <td><?php echo e($item->order_date); ?></td>
          <td><?php echo e($item->address); ?></td>
          <td><?php echo e(number_format($item->grand_total,0,'','.')); ?> ₫</td>
          <td><?php echo e($item->status); ?></td>
          <td>
            <a  href="<?php echo e(route('history.show', $item->id)); ?>"
            class="btn btn-primary">Detail</a>
            <?php if($item->status == "pending"): ?>
            <a onclick="return confirm('Are you sure to cancel order?')" href="<?php echo e(route('history.edit', $item->id)); ?>"
            class="btn btn-danger">Cancel</a>
              <?php endif; ?>
          </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
  </table>
  
  </div>

</div><!--end container-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sorcerersupreme/Documents/Programing/Workspace/GitHub/s2project/project/resources/views/frontend/order-history.blade.php ENDPATH**/ ?>