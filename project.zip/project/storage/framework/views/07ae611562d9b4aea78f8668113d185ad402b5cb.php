<?php $__env->startSection('contents'); ?>

    <div class="container">
        <div class="wrap-breadcrumb">
            <ul>
                <li class="item-link"><a href="<?php echo e(route('home')); ?>" class="link">home</a></li>
                <li class="item-link"><span>Blog Post</span></li>
            </ul>
        </div>
        <div class="row">
            <div class="col-lg-9 col-md-8 col-sm-8 col-xs-12 main-content-area">
                <div class="row">
                    <ul class="product-list grid-products equal-container" id="id01">
                        <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            
                            <li class="col-lg-4 col-md-6 col-sm-6 col-xs-6 ">
                                <div class="product product-style-3 equal-elem ">
                                    <div class="product-thumnail" style="display:flex;justify-content:center">
                                        <a href="<?php echo e(route('post-detail', $item->id)); ?>" title="<?php echo e($item->name); ?>">
                                            <figure><img src="<?php echo e(asset('images/' . $item->image)); ?>"
                                                    style="width: auto; height:166px;" alt="img"></figure>
                                        </a>
                                    </div>
                                    <div class="product-info">
                                        <div style="display:flex;justify-content:center" ><a href="<?php echo e(route('post-detail', $item->id)); ?>" class="product-name" ><span> <b><?php echo e($item->title); ?> </b></span></a></div>
                                        <div class="wrap-price" style="text-align: right"><span  > By <i><?php echo e($item->author); ?> </i></span>
                                        <div class="wrap-price" style="text-align: right"><span>Post day: <?php echo e($item->created_at -> format('d/m/Y')); ?> </span>

                                        </div>

                                        <a href="<?php echo e(route('post-detail', $item->id)); ?>" class="btn add-to-cart">Read more</a>
                                    </div>
                                </div>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="product product-style-3  equal-elem">
                                <h3 align="left">Waiting for new post </h3>
                            </div>
                        <?php endif; ?>
                    </ul>
                </div>

            </div>
            <!--end main products area-->
        </div>
    </div>
    <!--end container-->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sorcerersupreme/Documents/Programing/Workspace/GitHub/s2project/project/resources/views/frontend/post-index.blade.php ENDPATH**/ ?>