<?php $__env->startSection('contents'); ?>
<!-- Content Header (Page header) -->
<section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1>Blog Post</h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="#">Home</a></li>
            <li class="breadcrumb-item active">Blog Post</li>
          </ol>
        </div>
      </div>
    </div><!-- /.container-fluid -->
  </section>

  <!-- Main content -->
  <section class="content">

    <!-- Default box -->
    <div class="card">
      <div class="card-header">
        <h3 class="card-title">Post List</h3>

        <div class="card-tools">
          <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
            <i class="fas fa-minus"></i>
          </button>
          <button type="button" class="btn btn-tool" data-card-widget="remove" title="Remove">
            <i class="fas fa-times"></i>
          </button>
        </div>
      </div>
      <div class="card-body p-0">
        <table class="table table-striped projects">
          <thead>
              <tr>
                <th>Image</th>
                <th>Title</th>
                <th>Featured</th>
                <th>Category</th>
                <th>Author</th>
                <th>Sort</th>
                <th>Actions</th>
              </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td>
                <?php if($item->image != null): ?>
                <img src="<?php echo e(asset('/images/' . $item->image)); ?>" alt="<?php echo e($item->image); ?>" style="width: 150px; height:100px;">
                <?php endif; ?>
              </td>
              <td><?php echo e($item->title); ?></td>
              <td>
                <?php if($item->featured): ?>
                <span class="badge badge-success">Featured</span>
                <?php endif; ?>
              </td>
              <td><?php echo e($item->category->name); ?></td>
              <td><?php echo e($item->author); ?></td>
              <td><?php echo e($item->sort); ?></td>
              <td>
                <a href="<?php echo e(route('admin.post.edit', $item->id)); ?>" class="btn btn-primary">Update</a>
                <form style="display:inline-block" action="<?php echo e(route('admin.post.destroy', $item->id)); ?>" method="POST">
                  <?php echo method_field("DELETE"); ?>
                  <?php echo csrf_field(); ?>
                  <button class="btn btn-danger">Delete</button>
                </form>
              </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
      </table>
      </div>
      <!-- /.card-body -->
    </div>
    <!-- /.card -->

  </section>
  <!-- /.content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sorcerersupreme/Documents/Programing/Workspace/GitHub/s2project/project/resources/views/admin/post/index.blade.php ENDPATH**/ ?>