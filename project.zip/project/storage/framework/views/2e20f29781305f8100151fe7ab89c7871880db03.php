<h2>Hello Admin,</h2> <br> 
You received an email from : <?php echo e($name); ?> <br>
Here are the details:<br>
<b>Name:</b> <?php echo e($name); ?><br>
<b>Email:</b> <?php echo e($email); ?><br>
<b>Phone Number:</b> <?php echo e($phone); ?><br>
<b>Subject:</b> <?php echo e($subject); ?><br>
<b>Message:</b> <br>
 <?php echo $user_message; ?>


<br><br>
Thank You!<?php /**PATH /Users/sorcerersupreme/Documents/Programing/Workspace/GitHub/s2project/project/resources/views/admin/mail.blade.php ENDPATH**/ ?>