<?php $__env->startSection('contents'); ?>
<!-- Content Header (Page header) -->
<section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1>Post Categories</h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="#">Home</a></li>
            <li class="breadcrumb-item active">Post Categories</li>
          </ol>
        </div>
      </div>
    </div><!-- /.container-fluid -->
  </section>

  <!-- Main content -->
  <section class="content">

    <!-- Default box -->
    <div class="card">
      <div class="card-header">
        <h3 class="card-title">Post Categories Index</h3>

        <div class="card-tools">
          <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
            <i class="fas fa-minus"></i>
          </button>
          <button type="button" class="btn btn-tool" data-card-widget="remove" title="Remove">
            <i class="fas fa-times"></i>
          </button>
        </div>
      </div>
      <div class="card-body p-0">
        <div>
            <?php if(session('alert')): ?>
          
              <section class='alert alert-warning'><?php echo e(session('alert')); ?></section>
          
          <?php endif; ?>  
        </div>
        <table class="table table-striped projects">
          <thead>
              <tr>
                <th>Name</th>
                <th>Slug</th>
                <th>Sort</th>

                <th>Actions</th>
              </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $postCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($item->name); ?></td>
              <td><?php echo e($item->slug); ?></td>
              <td><?php echo e($item->sort); ?></td>

              <td>
                <form style="display:inline-block" action="<?php echo e(route('admin.post-category.destroy', $item->id)); ?>" method="POST">
                  <?php echo method_field("DELETE"); ?>
                  <?php echo csrf_field(); ?>
                  <button class="btn btn-danger">Delete</button>
                </form>
              </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
      </table>
      </div>
      <!-- /.card-body -->
    </div>
    <!-- /.card -->

  </section>
  <!-- /.content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sorcerersupreme/Documents/Programing/Workspace/GitHub/s2project/project/resources/views/admin/post-category/index.blade.php ENDPATH**/ ?>