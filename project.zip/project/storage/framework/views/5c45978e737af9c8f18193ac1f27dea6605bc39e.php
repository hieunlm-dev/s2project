<!-- Brand Logo -->
<a href="<?php echo e(route('admin.dashboard')); ?>" class="brand-link">
    <img src="<?php echo e(asset('images/logo.jpg')); ?>" alt="AdminLTE Logo" class="brand-image img-circle elevation-3" style="opacity: .8">
    <span class="brand-text font-weight-light">2HAT STORE</span>
  </a>

  <!-- Sidebar -->
  <div class="sidebar">
    <!-- Sidebar user (optional) -->
    <div class="user-panel mt-3 pb-3 mb-3 d-flex">
      <div class="image">
        <img src="<?php echo e(asset('images/'.Session::get('user')->image)); ?>" class="img-circle elevation-2" alt="User Image">
      </div>
      <div class="info">
        <a href="<?php echo e(route('admin.account.edit',session()->get('user')->id )); ?>" class="d-block"> <?php echo e(Session::get('user')->username); ?> </a>
      </div>
    </div>

    <!-- Sidebar Menu -->
    <nav class="mt-2">
      <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
        <!-- Add icons to the links using the .nav-icon class
             with font-awesome or any other icon font library -->
        <li class="nav-item">
          <a href="<?php echo e(route('admin.dashboard')); ?>" class="nav-link">
            <i class="nav-icon fas fa-tachometer-alt"></i>
            <p>
              Dashboard
            </p>
          </a>
        </li>
        
        <li class="nav-item">
          <a href="#" class="nav-link">
            <i class="nav-icon fas fa-user"></i>
            <p>
              Admin
              <i class="right fas fa-angle-left"></i>
            </p>
          </a>
          <ul class="nav nav-treeview">
            <li class="nav-item">
              <a href="<?php echo e(route('admin.account.index')); ?>" class="nav-link">
                <i class="far fa-circle nav-icon"></i>
                <p>Admin</p>
              </a>
            </li>
            <?php if(session()->get('user')->role=='admin'): ?>
            <li class="nav-item">
              <a href="<?php echo e(route('admin.account.create')); ?>" class="nav-link">
                <i class="far fa-circle nav-icon"></i>
                <p>Create Admin</p>
              </a>
            </li>
            <?php endif; ?>
          </ul>
        </li>
        <li class="nav-item">
          <a href="<?php echo e(route('admin.customer.index')); ?>" class="nav-link">
            <i class="nav-icon fas fa-users"></i>
            <p>
              Customer Management
            </p>
          </a>
        </li>
        <li class="nav-item">
          <a href="#" class="nav-link">
            <i class="nav-icon fab fa-product-hunt"></i>
            <p>
              Product
              <i class="right fas fa-angle-left"></i>
            </p>
          </a>
          <ul class="nav nav-treeview">
            <li class="nav-item">
              <a href="<?php echo e(route('admin.product.index')); ?>" class="nav-link">
                <i class="far fa-circle nav-icon"></i>
                <p>Product List</p>
              </a>
            </li>
            <li class="nav-item">
              <a href="<?php echo e(route('admin.product.create')); ?>" class="nav-link">
                <i class="far fa-circle nav-icon"></i>
                <p>Create Product</p>
              </a>
            </li>
            
          </ul>
        </li>

        <li class="nav-item">
          <a href="#" class="nav-link">
            <i class="nav-icon far fa-copyright"></i>
            <p>
              Brand
              <i class="right fas fa-angle-left"></i>
            </p>
          </a>
          <ul class="nav nav-treeview">
            <li class="nav-item">
              <a href="<?php echo e(route('admin.brand.index')); ?>" class="nav-link">
                <i class="far fa-circle nav-icon"></i>
                <p>Brand List</p>
              </a>
            </li>
            <li class="nav-item">
              <a href="<?php echo e(route('admin.brand.create')); ?>" class="nav-link">
                <i class="far fa-circle nav-icon"></i>
                <p>Create Brand</p>
              </a>
            </li>
          </ul>
        </li>
        
        <li class="nav-item">
          <a href="#" class="nav-link">
            <i class="nav-icon fas fa-file-invoice-dollar"></i>
            <p>
              Order
              <i class="right fas fa-angle-left"></i>
            </p>
          </a>
          <ul class="nav nav-treeview">
            <li class="nav-item">
              <a href="<?php echo e(route('admin.order.index')); ?>" class="nav-link">
                <i class="far fa-circle nav-icon"></i>
                <p>Order List</p>
              </a>
            </li>
            
          </ul>
        </li>
        
        <li class="nav-item">
          <a href="#" class="nav-link">
            <i class="nav-icon fab fa-blogger"></i>
            <p>
              Blog Post
              <i class="right fas fa-angle-left"></i>
            </p>
          </a>
          <ul class="nav nav-treeview">
            <li class="nav-item">
              <a href="<?php echo e(route('admin.post.index')); ?>" class="nav-link">
                <i class="far fa-circle nav-icon"></i>
                <p>Post index</p>
              </a>
            </li>
            <li class="nav-item">
              <a href="<?php echo e(route('admin.post.create')); ?>" class="nav-link">
                <i class="far fa-circle nav-icon"></i>
                <p>Create Post</p>
              </a>
            </li>
          </ul>
        </li>
        
        <li class="nav-item">
          <a href="#" class="nav-link">
            <i class="nav-icon fab fa-blogger-b"></i>
            <p>
              Post Category
              <i class="right fas fa-angle-left"></i>
            </p>
          </a>
          <ul class="nav nav-treeview">
            <li class="nav-item">
              <a href="<?php echo e(route('admin.post-category.index')); ?>" class="nav-link">
                <i class="far fa-circle nav-icon"></i>
                <p>Post Category Index</p>
              </a>
            </li>
            <li class="nav-item">
              <a href="<?php echo e(route('admin.post-category.create')); ?>" class="nav-link">
                <i class="far fa-circle nav-icon"></i>
                <p>Create Post Category</p>
              </a>
            </li>
          </ul>
        </li>

      </ul>
    </nav>
    <!-- /.sidebar-menu -->
  </div>
  <!-- /.sidebar --><?php /**PATH /Users/sorcerersupreme/Documents/Programing/Workspace/GitHub/s2project/project/resources/views/admin/layout/partials/sidebar.blade.php ENDPATH**/ ?>