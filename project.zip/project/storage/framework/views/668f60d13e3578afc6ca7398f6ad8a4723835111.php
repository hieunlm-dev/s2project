<?php $__env->startSection('contents'); ?>

<div class="container">

			<div class="wrap-breadcrumb">
				<ul>
					<li class="item-link"><a href="#" class="link">home</a></li>
					<li class="item-link"><span>Post</span></li>
				</ul>
			</div>
			<div class="row">
                <h2 style="text-align: center; font-weight:bolder; padding-left:100px; padding-right:100px"><?php echo $post->title; ?></h2>
                <p style="text-align: right; padding-right:20px">By <i><?php echo e($post->author); ?></i></p>
                <p style="text-align: right; padding-right:20px"><i>Post day: <?php echo e($post->created_at -> format('d/m/Y')); ?></i></p>
                <div class="col-md-12">
                   <?php echo $post->contents; ?>

                </div>
			</div><!--end row-->
		</div><!--end container-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sorcerersupreme/Documents/Programing/Workspace/GitHub/s2project/project/resources/views/frontend/post-detail.blade.php ENDPATH**/ ?>