<?php $__env->startSection('contents'); ?>

<div class="container">
    <div class="wrap-breadcrumb">
        <ul>
            <li class="item-link"><a href="<?php echo e(route('home')); ?>" class="link">home</a></li>
            <li class="item-link"><span>check-out</span></li>
        </ul>
    </div>
    
    <?php if(Session::has('cart') || !empty(Session::get('cart'))): ?>
    <div class=" main-content-area">
        <form action="<?php echo e(route('do-checkout')); ?>" method="post" name="frm-billing" onsubmit="if (this.createAccount.checked == false) { alert ('Please check create account to place order!'); return false; } else { return true; }">
            <?php echo csrf_field(); ?> 
            <div class="wrap-address-billing" style="width: 100%" >
                <h3 class="box-title">Billing Address</h3>   
                <p class="row-in-form">
                    <label for="fname">first name<span>*</span></label>
                    <input id="fname" type="text" name="fname" required placeholder="Your name" <?php if(Session::has('customer') ): ?> value="<?php echo e(session()->get('customer')->firstname); ?>"<?php endif; ?>>
                </p>
                <p class="row-in-form">
                    <label for="lname">last name<span>*</span></label>
                    <input id="lname" type="text" name="lname" required  placeholder="Your last name"  <?php if(Session::has('customer') ): ?> value="<?php echo e(session()->get('customer')->lastname); ?>"<?php endif; ?>>
                </p>
                <?php if(Session::has('customer')): ?>
                    <p class="row-in-form">
                    <label for="email">Email Address</label>
                    <input id="email" type="email" name="email" placeholder="Type your email" <?php if(Session::has('customer') ): ?> value="<?php echo e(session()->get('customer')->email); ?>"<?php endif; ?>>
                </p>
                <?php else: ?>
                    <p class="row-in-form">
                    <label for="email">Email Address<span>*</span></label>
                    <input id="email" type="email" name="email" required placeholder="Type your email" <?php if(Session::has('customer') ): ?> value="<?php echo e(session()->get('customer')->email); ?>"<?php endif; ?>>
                </p>
                <?php endif; ?>
                
                <p class="row-in-form">
                    <label for="phone">Phone number<span>*</span></label>
                    <input id="phone" type="text" name="phone" required placeholder="10 digits format"  <?php if(Session::has('customer') ): ?> value="<?php echo e(session()->get('customer')->phone); ?>"<?php endif; ?>>
                </p>
                <p class="row-in-form">
                    <label for="add">Address:<span>*</span></label>
                    <input id="add" type="text" name="add" required  placeholder="Type your address"  <?php if(Session::has('customer') ): ?> value="<?php echo e(session()->get('customer')->address); ?>"<?php endif; ?>>
                </p>

                <?php if(!session()->has('customer')): ?>
                <p class="row-in-form fill-wife">
                    <label class="checkbox-field">
                        <input name="createAccount" id="create-account" type="checkbox" checked >
                        <span>Create an account <span>*</span></span>
                    </label>
                </p>
                <?php endif; ?>  
            </div>
            <div class="row-in-form">
                <b>Field with <span style="color:red">*</span> is required</b>  
           </div>
            <div class="summary summary-checkout">
                <div class="summary-item payment-method">
                    <h4 class="title-box">Payment Method</h4>
                    <p class="summary-info"><span class="title">Check / Money order</span></p>
                    <p class="summary-info"><span class="title">Credit Cart (saved)</span></p>
                    <div class="choose-payment-methods">
                        <label class="payment-method">
                            <input id="payment-method-cod" name="payment-method" value="cod" type="radio" checked>
                            <span>Cash On Delivery(COD)</span>
                            <span class="payment-desc">Customer pays for a good at the time of delivery</span>
                        </label>
                        <label class="payment-method">
                            <input id="payment-method-paypal" name="payment-method" value="paypal" type="radio">
                            <span>Paypal</span>
                            <span class="payment-desc">You can pay with your credit</span>
                            <span class="payment-desc">card if you don't have a paypal account</span>
                        </label>

                    </div>
                    
                     <?php
                        $total = 0;
                    ?>
                    <?php $__currentLoopData = Session::get('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $total += $item->quantity * $item->price;
                        ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <p class="summary-info grand-total"><span>Grand Total</span> <span class="grand-total-price"><?php echo e(number_format($total,0,'','.')); ?>₫</span></p>
                    <button type="submit" id="order-button" class="btn btn-medium">Place order now</button>
                </div>
                <div class="summary-item shipping-method">
                    <h4 class="title-box f-title">Shipping method</h4>
                    <p class="summary-info"><span class="title"><b>Free Shipping</b></span></p>
                    
                </div>
            </div>
        </form>
    </div><!--end main content area-->    
    <?php else: ?>
       <div class="text-center" style="padding:30px 0;">
            <h1>Your cart is empty</h1>
            <p>Add items to it now</p>
            <a href="<?php echo e(route('shop')); ?>" class="btn btn-success">Shop Now</a>
    </div> 
    <?php endif; ?>
</div><!--end container-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sorcerersupreme/Documents/Programing/Workspace/GitHub/s2project/project/resources/views/frontend/checkout.blade.php ENDPATH**/ ?>