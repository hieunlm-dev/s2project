<?php $__env->startSection('contents'); ?>
    

<div class="container">

    <!--MAIN SLIDE-->
    <div class="wrap-main-slide">
        <?php echo $__env->make('frontend.home.slideshow', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 

    <!--BANNER-->
    <div class="wrap-banner style-twin-default">
        <div class="banner-item">
            <a href="#" class="link-banner banner-effect-1">
                <figure><img src="<?php echo e(asset('assets/images/iphone.png')); ?>" alt="" width="580" height="190"></figure>
            </a>
        </div>
        <div class="banner-item">
            <a href="#" class="link-banner banner-effect-1">
                <figure><img src="<?php echo e(asset('assets/images/samsung.jpg')); ?>" alt="" width="580" height="190"></figure>
            </a>
        </div> 
    </div>

    <!--Featured-->
    <div class="wrap-show-advance-info-box style-1" >
        <?php echo $__env->make('frontend.home.featuredProduct', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

    <!--Latest Products-->
    <div class="wrap-show-advance-info-box style-1">
        <?php echo $__env->make('frontend.home.latestProduct', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
    </div>
    		

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sorcerersupreme/Documents/Programing/Workspace/GitHub/s2project/project/resources/views/frontend/home.blade.php ENDPATH**/ ?>