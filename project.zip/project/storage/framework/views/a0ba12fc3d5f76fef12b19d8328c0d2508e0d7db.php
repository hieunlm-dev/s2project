<?php $__env->startSection('contents'); ?>
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Admin Management</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Home</a></li>
                        <li class="breadcrumb-item active">Admin</li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">

        <!-- Default box -->
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Admin Accounts</h3>

                <div class="card-tools">
                    <?php if(session()->get('user')->role=='admin'): ?>
                    <a href="<?php echo e(route('admin.account.create')); ?>"><i class="fas fa-user-plus"></i></a>
                    <?php endif; ?>
                    <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
                        <i class="fas fa-minus"></i>
                    </button>
                    <button type="button" class="btn btn-tool" data-card-widget="remove" title="Remove">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
            </div>
            <div class="card-body p-0">
                <table class="table table-striped projects">
                    <thead>
                        <tr>
                            <th>Image</th>
                            <th>Username</th>
                            <th>Email</th>
                            <th>Role</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <?php if($item->image != null): ?>
                                        <img src="<?php echo e(asset('/images/' . $item->image)); ?>" alt="<?php echo e($item->image); ?>"
                                            style="width: 50px; height:50px; border-radius:50%">
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($item->username); ?></td>
                                <td><?php echo e($item->email); ?></td>
                                <td><?php echo e($item->role); ?></td>
                                
                                <td>
                                        <?php if(session()->get('user')->id == $item->id): ?>
                                        <a href="<?php echo e(route('admin.account.edit', $item->id)); ?>"
                                            class="btn btn-primary">Update</a>
                                            <?php endif; ?>
                                  
                                    <?php if(session()->get('user')->role == 'admin' && session()->get('user')->username != $item->username &&$item->role == 'user'): ?>
                                        <a href="<?php echo e(route('admin.account.edit', $item->id)); ?>"
                                            class="btn btn-primary">Update Role</a>
                                        <form style="display:inline-block"
                                            action="<?php echo e(route('admin.account.destroy', $item->id)); ?>" method="POST">
                                            <?php echo method_field("DELETE"); ?>
                                            <?php echo csrf_field(); ?>
                                            <button class="btn btn-danger">Delete</button>
                                        </form>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <!-- /.card-body -->
        </div>
        <!-- /.card -->

    </section>
    <!-- /.content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sorcerersupreme/Documents/Programing/Workspace/GitHub/s2project/project/resources/views/admin/account/index.blade.php ENDPATH**/ ?>