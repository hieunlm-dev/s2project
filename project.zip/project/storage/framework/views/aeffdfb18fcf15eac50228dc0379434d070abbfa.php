<?php $__env->startSection('contents'); ?>

<div class="container">

			<div class="wrap-breadcrumb">
				<ul>
					<li class="item-link"><a href="<?php echo e(route('home')); ?>" class="link">home</a></li>
					<li class="item-link"><span>All Products</span></li>
				</ul>
			</div>
			<div class="row">
				<div class="col-lg-9 col-md-8 col-sm-8 col-xs-12 main-content-area">
					<div class="banner-shop">
						<a href="#" class="banner-link">
							<figure><img src="assets/images/shop-banner.jpg" alt=""></figure>
						</a>
					</div>
					<div>
						  <?php if(session('alert')): ?>
						
						    <section class='alert alert-warning'><?php echo e(session('alert')); ?></section>
						
						<?php endif; ?>  
					 
						  <?php if(session('alert1')): ?>
						
						    <section class='alert alert-success'><?php echo e(session('alert1')); ?></section>
						
						<?php endif; ?>  
					</div>
					
					<form action="<?php echo e(route('sort')); ?>">
						<div class="wrap-shop-control">	

						<h1 class="shop-title">Mobile Store</h1>

						<div class="wrap-right">
							
							<div class="sort-item orderby ">
								<select name="orderby" class="use-chosen" onchange="this.form.submit()">
									<option value="date" >Sort by date</option>
									<option value="price">Sort by price: low to high</option>
									<option value="price-desc">Sort by price: high to low</option>
									<option value="5000000">Under 5M</option>
									<option value="10000000">From 5M to 10M</option>
									<option value="20000000">From 10M to 20M</option>
									<option value="20000001">Over 20M</option>
								</select>
							</div>
						</div>
					</div><!--end wrap shop control-->
					</form>

					<div class="row">
						
					
						<ul class="product-list grid-products equal-container" id="id01">
							
							<?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
								<li class="col-lg-4 col-md-6 col-sm-6 col-xs-6 ">
								<div class="product product-style-3 equal-elem ">
									<div class="product-thumnail">
										<a href="<?php echo e(route('product-details',$item->id)); ?>" title="<?php echo e($item->name); ?>">
											<figure><img src="<?php echo e(asset('images/'.$item->image)); ?>" style="width: auto; height:166px;" alt="img"></figure>
										</a>
									</div>
									
									<div class="product-info">
										<a href="<?php echo e(route('product-details',$item->id)); ?>" class="product-name"><span><?php echo e($item->name); ?></span></a>
										<div class="wrap-price"><span class="product-price"><?php echo e(number_format($item->price,0,'','.')); ?> ₫</span></div>
										<input type="hidden" id="pid" value="<?php echo e($item->id); ?>">
										<?php if($item->quantity != 0): ?>  
										<a href="#" class="btn add-to-cart" data-id="<?php echo e($item->id); ?>">Add To Cart</a>
										<?php else: ?>
										<a href="<?php echo e(route('product-details',$item->id)); ?>" class="btn add-to-cart" >Not Available</a>
										<?php endif; ?>
									</div>
						
								</div>
							</li>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
								 <div class="product product-style-3  equal-elem">
                                <h3 align="center">Cannot find your product </h3>
                            </div>
							<?php endif; ?>
						</ul>
					</div>
					<div class="wrap-pagination-info">
						<div class="d-flex justify-content-center">
							<?php echo $products->appends(request()->input())->links(); ?>

						
						</div>
					</div>
				</div><!--end main products area-->

				<div class="col-lg-3 col-md-4 col-sm-4 col-xs-12 sitebar">

					<div class="widget mercado-widget filter-widget brand-widget">
						<h2 class="widget-title">Brand</h2>
						<div class="widget-content">
							<ul class="list-style vertical-list list-limited" data-show="6">
							
								<form action="<?php echo e(route('shop')); ?>" >
									<?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									
									<div><input type="submit" class="btn btn-secondary" style="width: 90px; margin:2px" value="<?php echo e($item->name); ?>" name="brand"></div>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</form>
								
							
							</ul>
						</div>
					</div><!-- brand widget-->

				</div><!--end sitebar-->

			</div><!--end row-->

		</div><!--end container-->

<?php $__env->stopSection(); ?>

<?php if(isset($item)): ?>
<?php $__env->startSection('my-scripts'); ?>
<script>
	// setup csrf-token cho post method
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

    $('.add-to-cart').click(function(e) {
        e.preventDefault();     // hủy chức năng chuyển trang của thẻ a
        quantity = 1;
		pid = $(this).data('id');
        // pid= $('#pid').val();
        //alert(quantity);

        $.ajax({
            type:'GET',
            url:'<?php echo e(route('add-cart')); ?>',
            data:{pid:pid, quantity:quantity},
            success:function(data){
                swal({
					title: "Adding successfully",
					text: "This product has been successfully added to your cart",
					icon: "success",
					button: "Okay!",
				}).then(function(){
					window.location.reload();
				});
            }
        });	
	})
</script>
<?php $__env->stopSection(); ?>
<?php endif; ?>
<?php echo $__env->make('frontend.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sorcerersupreme/Documents/Programing/Workspace/GitHub/s2project/project/resources/views/frontend/shop.blade.php ENDPATH**/ ?>