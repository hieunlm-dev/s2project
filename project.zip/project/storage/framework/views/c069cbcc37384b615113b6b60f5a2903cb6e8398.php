<?php $__env->startSection('contents'); ?>


<div class="container">

<center><h2>Wish  List</h2></center>

<div class="card-body p-0">
    <table class="table table-striped projects">
      <thead>
          <tr>
            
            <th>Name</th>
            <th>Image</th>
            <th>Price</th>
            <th>Status</th>
            <th>Action</th>
          </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $lists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
  
          <td><?php echo e($item->product['name']); ?></td>
          <td><img src="<?php echo e(asset('/images/'.$item->product['image'])); ?>" alt="" style="width: auto; height:80px;"></td>
          <td><?php echo e(number_format($item->product['price'],0,'','.')); ?>₫</td>
          <td>
            <?php if($item->product['quantity']>0): ?>
            Available
            <?php else: ?>
            Not Available
            <?php endif; ?>
          </td>
         <td>
          <a href="#"
            class="btn btn-primary add-to-cart" data-id="<?php echo e($item->product['id']); ?>">Add To Cart</a>
        <form style="display:inline-block"
            action="<?php echo e(route('wish-list.destroy', $item->id)); ?>" method="POST">
            <?php echo method_field("DELETE"); ?>
            <?php echo csrf_field(); ?>
            <button class="btn btn-danger">Delete</button>
        </form>

         </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
  </table>
  </div>
</div><!--end container-->

<?php $__env->stopSection(); ?>
<?php if(isset($item)): ?>
<?php $__env->startSection('my-scripts'); ?>
<script>
	// setup csrf-token cho post method
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

    $('.add-to-cart').click(function(e) {
        e.preventDefault();     // hủy chức năng chuyển trang của thẻ a
        quantity = 1;
		    pid = $(this).data('id');
        // pid= $('#pid').val();
        //alert(quantity);

        $.ajax({
            type:'GET',
            url:'<?php echo e(route('add-cart')); ?>',
            data:{pid:pid, quantity:quantity},
            success:function(data){
                swal({
					title: "Adding successfully",
					text: "This product has been successfully added to your cart",
					icon: "success",
					button: "Aww yiss!",
				}).then(function(){
					window.location.reload();
				});
            }
        });	
	})
</script>
<?php $__env->stopSection(); ?>
<?php endif; ?>
<?php echo $__env->make('frontend.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sorcerersupreme/Documents/Programing/Workspace/GitHub/s2project/project/resources/views/frontend/wish-list.blade.php ENDPATH**/ ?>