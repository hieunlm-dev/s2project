<?php $__env->startSection('contents'); ?>
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Customer Management</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Home</a></li>
                        <li class="breadcrumb-item active">Account</li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
        <!-- Default box -->
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Customer Detail</h3>

                <div class="card-tools">
                    <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
                        <i class="fas fa-minus"></i>
                    </button>
                    <button type="button" class="btn btn-tool" data-card-widget="remove" title="Remove">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
            </div>
            <div class="card-body">
                <div class="form-group">
                    <label for="username">First Name</label>
                    <input type="text" id="username" name="username" value="<?php echo e($customer->firstname); ?>"
                        class="form-control" readonly />
                </div>
                <div class="form-group">
                    <label for="username">Last Name</label>
                    <input type="text" id="username" name="username" value="<?php echo e($customer->lastname); ?>"
                        class="form-control" readonly />
                </div>
                <div class="form-group">
                    <label for="confirm">Email</label>
                    <input type="text" id="confirm" name="confirm" class="form-control" value="<?php echo e($customer->email); ?>"
                        readonly />
                </div>
                <div class="form-group">
                    <label for="email">Phone</label>
                    <input type="text" id="email" name="email" value="<?php echo e($customer->phone); ?>" class="form-control"
                        readonly />
                </div>
                <div class="form-group">
                    <label for="email">Address</label>
                    <input type="text" id="email" name="email" value="<?php echo e($customer->address); ?>" class="form-control"
                        readonly />
                </div>
                
            </div>
        </div>
        </div>
    </section>
    <!-- /.content -->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sorcerersupreme/Documents/Programing/Workspace/GitHub/s2project/project/resources/views/admin/customer/detail.blade.php ENDPATH**/ ?>